SCRIPT SetUpBasicLights 
ENDSCRIPT


